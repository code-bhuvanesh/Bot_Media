package com.code_bhuvanesh.BotMedia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BotMediaApplicationTests {

	@Test
	void contextLoads() {
	}

}
