package com.code_bhuvanesh.BotMedia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BotMediaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BotMediaApplication.class, args);
	}

}
